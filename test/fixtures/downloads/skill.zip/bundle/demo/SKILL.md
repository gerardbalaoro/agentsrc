---
name: demo
description: Download fixture
---
Downloaded skill.
